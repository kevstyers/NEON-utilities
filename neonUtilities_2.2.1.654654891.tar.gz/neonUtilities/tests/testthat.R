library(testthat)
library(neonUtilities)

test_check("neonUtilities")
